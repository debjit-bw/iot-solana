"""Client code for interacting with the Memo Program."""
